    <nav class="navbar fixed-top navbar-toggleable-md navbar-inverse bg-inverse">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="container" >
             <img src="images/logo11.jpg" alt="logo" height="70px"class="nav-link" style="border-radius: 100px;border-color:red;  transform: rotateX(150deg);  transform: rotateY(150deg);">
            <a class="navbar-brand" href="index.php">BLOOD BANK AND DONOR </a>
            <div class="collapse navbar-collapse" id="navbarExample">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="page.php?type=aboutus" style="text-shadow: 0 0 3px #FF0000;">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="page.php?type=donor"style="text-shadow: 0 0 3px #FF0000;">Why Become Donor</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="become-donar.php" style="text-shadow: 0 0 3px #FF0000;">Become a Donar</a>
                    </li>

                     <li class="nav-item">
                        <a class="nav-link" href="search-donor.php"style="text-shadow: 0 0 3px #FF0000;">Search Blood</a>
                    </li>
                      <li class="nav-item">
                        <a class="nav-link" href="contact.php" style="text-shadow: 0 0 3px #FF0000;">Contact us</a>
                    </li>


                </ul>
            </div>
        </div>
    </nav>
