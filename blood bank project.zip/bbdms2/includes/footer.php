

  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; BloodBank & Donor Management System By <a href="https://SAURABHPRAKASH.org/">100rabh Prakash</a></p>
        </div>
        <!-- /.container -->
    </footer>
